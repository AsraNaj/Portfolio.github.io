const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());

const users = [];

app.post('/signup', (req, res) => {
    const { name, email, password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
        return res.json({ success: false, message: 'Passwords do not match' });
    }
    const userExists = users.find(user => user.email === email);
    if (userExists) {
        return res.json({ success: false, message: 'User already exists' });
    }
    users.push({ name, email, password });
    res.json({ success: true, message: 'Signup successful' });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(user => user.email === username);
    if (!user) {
        return res.json({ success: false, message: 'You have not signed up yet' });
    }
    if (user.password !== password) {
        return res.json({ success: false, message: 'Invalid password' });
    }
    res.json({ success: true, message: 'Login successful' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});
