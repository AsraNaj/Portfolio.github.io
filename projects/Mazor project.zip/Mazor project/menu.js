function toggleDropdown() {
    var dropdownContent = document.getElementById('dropdown-content');
    if (dropdownContent.style.display === 'block') {
        dropdownContent.style.display = 'none';
    } else {
        dropdownContent.style.display = 'block';
    }
}
document.addEventListener("DOMContentLoaded", () => {
    const grid = document.querySelector('.food-grid');
    const nextButton = document.querySelector('.right-arrow');
    const prevButton = document.querySelector('.left-arrow');
    let currentItem = 0; // Start at the first item
    const itemsPerView = 6; // Number of items visible at one time

    // Function to calculate and apply translation
    function updateTranslation() {
        grid.style.transform = `translateX(-${(100 / itemsPerView) * currentItem}%)`;
    }

    nextButton.addEventListener('click', () => {
        const totalItems = grid.children.length;
        if (currentItem < totalItems - itemsPerView) { // Ensure there's enough items left to scroll right
            currentItem++;
            updateTranslation();
        }
    });

    prevButton.addEventListener('click', () => {
        if (currentItem > 0) { // Ensure you're not at the first item
            currentItem--;
            updateTranslation();
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn !== 'true') {
        alert('You must log in first.');
        window.location.href = 'login.html';
    }
});


